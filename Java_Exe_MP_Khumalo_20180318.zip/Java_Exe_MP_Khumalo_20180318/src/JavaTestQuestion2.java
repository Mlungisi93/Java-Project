import java.util.Scanner;

public class JavaTestQuestion2 {
    private static String input;
    private static String option;
    private static String firstArgument;
    private static String secondArgument;
    private static int length;
    private static boolean isQuit = false;

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        while (isQuit == false) {
            System.out.println("");
            System.out.print("Enter Here: ");
            input = sc.nextLine();


            separateStringOption(input);
            if (option == null) {
                System.out.println("Input can't be empty");
            } else {
                switch (option.toLowerCase()) {
                    case "odd":
                        try {
                            //separateStringTwo(input);

                            odd(input);

                        } catch (NumberFormatException ex) {
                            System.out.println("Invalid value: only int accepted!");
                        }
                        break;

                    case "even":
                        try {
                            //separateStringTwo(input);
                            //int number = Integer.parseInt(firstArgument);

                            even(input);

                        } catch (NumberFormatException ex) {
                            System.out.println("Invalid value: only int accepted!");
                        }
                        break;

                    case "square":
                        try {
                            square(input);

                        } catch (NumberFormatException ex) {
                            System.out.println("Invalid value: only int accepted!");
                        }
                        break;

                    case "show":
                        show(input);
                        break;

                    case "concat":
                        concat(input);
                        break;

                    case "range":
                        separateThreeStrings(input);
                        try {
                            range(input);
                        } catch (NumberFormatException ex) {
                            System.out.println("Invalid value: only int accepted!");
                        }
                        break;

                    case "quit":
                        quit();
                        break;

                    default:
                        System.out.println("Invalid option!, choose: odd, even, square or show, concate, range or quit to stop the program");
                        break;


                }
            }

        }

    }

    public static void separateStringOption(String input) {
        String[] splitArray = input.split(" ");


        option = splitArray[0];


    }

    public static boolean separateStringTwo(String input) {
        String[] splitArray = input.split(" ");
        if (splitArray.length == 2) {

            firstArgument = splitArray[1];
            return true;
        } else {
            System.out.printf("Invalid option!, 2 arguments required and you entered " + splitArray.length + " argument%s: " + input + "\n", splitArray.length != 1 ? "s" : "");

        }
        return false;
    }

    public static boolean separateThreeStrings(String input) {
        String[] splitArray = input.split(" ");

        if (splitArray.length == 3) {

            firstArgument = splitArray[1];
            secondArgument = splitArray[2];
            return true;
        } else {
            System.out.printf("Invalid option!, 3 arguments required and you entered " + splitArray.length + " argument%s: " + input + "\n", splitArray.length != 1 ? "s" : "");
        }
        return false;
    }

    public static void odd(String input) {
        if (separateStringTwo(input) == true) {
            int value = Integer.parseInt(firstArgument);
            if (value % 2 != 0) {
                System.out.println("YES");
            } else {
                System.out.println("NO");
            }
        }


    }

    public static void even(String input) {

        if (separateStringTwo(input) == true) {
            int value = Integer.parseInt(firstArgument);
            if (value % 2 == 0) {
                System.out.println("YES");
            } else {
                System.out.println("NO");
            }

        }


    }

    public static void square(String input) {
        if (separateStringTwo(input) == true) {
            int value = Integer.parseInt(firstArgument);
            if (value < 0) {
                System.out.println("Can't evaluate a square root of negetive");
            } else {
                System.out.println(Math.sqrt(value));
            }
        }


    }

    public static void show(String input) {
        if (separateStringTwo(input)) {
            System.out.println(firstArgument);
        }

    }

    public static void concat(String input) {
        if (separateThreeStrings(input) == true) {
            System.out.println(firstArgument.toLowerCase() + secondArgument.toLowerCase());
        }

    }

    public static void range(String input) {

        if (separateThreeStrings(input) == true) {
            int a = Integer.parseInt(firstArgument);
            int b = Integer.parseInt(secondArgument);

            if (a > b) {
                System.out.println("Invalid range");
            } else {
                //System.out.println("Range From " + a + " to " + b);
                for (int i = a; i <= b; i++) {
                    System.out.print(i + " ");
                }
                System.out.println("");
            }

        }


    }

    public static void quit() {
        System.out.println("Program ended. Bye!");
        isQuit = true;

    }

}
